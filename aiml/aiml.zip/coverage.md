
I'm aiming to cover AIML 1.0.1, plus some additional custom tags.


AIML Coverage
=============

* Main
  * ✔ Category
  * ✘ Topic
  * ✔ Pattern
    * ✘ That
* Template
  * ✔ Star
  * ✔ That
  * ✔ Input
  * ✔ Thatstar
  * ✘ Topicstar
  * ✔ Get
  * ✔ Bot
* Shortcuts
  * ✔ Sr
  * ✔ Person
  * ✔ Person2
  * ✔ Gender
* System
  * ✔ Date
  * ✔ Size
  * ✔ Version
* Formatting
  * ✔ Uppercase
  * ✔ Lowercase
  * ✔ Formal
  * ✔ Sentence
* Conditional
  * ✘ Condition
  * ✔ Random
* Capture
  * ✔ Set
  * ✘ Gossip
* Symbolic Reduction
  * ✔ SRAI
* Transformationasl
  * ✔ Person
  * ✔ Person2
  * ✔ Gender
* Covert
  * ✔ Think
  * ✘ Learn
* External Processor
  * ✘ System

Won't Implement
===============

  * ✘ Javascript (this will NOT be implemented)
  * ✘ Deprecated tags (personf, etc.)
